let nombre = "";
let puntaje = 0;
let mejorPuntaje = 0;

window.onload = function () {
  document.getElementById("boton-ok").addEventListener("click", comenzarJuego);
  document.getElementById("boton-salir").addEventListener("click", salirDelJuego);
};

function comenzarJuego() {
  const input = document.getElementById("nombreJugador");
  nombre = input.value.trim();

  if (nombre === "") {
    alert("Por favor, escribí tu nombre.");
    return;
  }

  document.getElementById("nombre-container").style.display = "none";
  document.getElementById("juego").style.display = "block";

  // Traer puntaje anterior desde el servidor
  fetch(`obtener_ranking.php?nombre=${encodeURIComponent(nombre)}`)
    .then((response) => response.json())
    .then((data) => {
      mejorPuntaje = data.puntaje || 0;
      console.log("Puntaje anterior:", mejorPuntaje);
    })
    .catch((error) => {
      console.error("Error al obtener el puntaje anterior:", error);
    });
}

function jugar(eleccionJugador) {
  const opciones = ["piedra", "papel", "tijera"];
  const eleccionBot = opciones[Math.floor(Math.random() * 3)];

  let resultado = "";

  if (eleccionJugador === eleccionBot) {
    resultado = "¡Empate!";
  } else if (
    (eleccionJugador === "piedra" && eleccionBot === "tijera") ||
    (eleccionJugador === "papel" && eleccionBot === "piedra") ||
    (eleccionJugador === "tijera" && eleccionBot === "papel")
  ) {
    resultado = "¡Ganaste!";
    puntaje++;

    // Si el nuevo puntaje supera el récord, lo guardamos
    if (puntaje > mejorPuntaje) {
      guardarPuntaje(nombre, puntaje);
      mejorPuntaje = puntaje;
      mostrarMensaje("¡Nuevo récord!");
    }
  } else {
    resultado = "Perdiste.";
  }

  document.getElementById("resultado").textContent =
    resultado + " El bot eligió: " + eleccionBot;
  document.getElementById("puntaje").textContent = puntaje;
}

function salirDelJuego() {
  window.location.href = "index.html";
}

function guardarPuntaje(nombre, puntaje) {
  fetch("guardar_ranking.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: `nombre=${encodeURIComponent(nombre)}&puntaje=${puntaje}`,
  })
    .then((response) => {
      if (response.ok) {
        console.log("Puntaje guardado correctamente.");
      } else {
        console.error("Error al guardar el puntaje.");
      }
    })
    .catch((error) => {
      console.error("Error de red:", error);
    });
}

function mostrarMensaje(mensaje) {
  const divMensaje = document.createElement("div");
  divMensaje.textContent = mensaje;
  divMensaje.style.position = "fixed";
  divMensaje.style.top = "20px";
  divMensaje.style.left = "50%";
  divMensaje.style.transform = "translateX(-50%)";
  divMensaje.style.backgroundColor = "#4CAF50";
  divMensaje.style.color = "white";
  divMensaje.style.padding = "10px 20px";
  divMensaje.style.borderRadius = "10px";
  divMensaje.style.boxShadow = "0px 4px 8px rgba(0,0,0,0.2)";
  divMensaje.style.zIndex = 1000;

  document.body.appendChild(divMensaje);

  setTimeout(() => {
    document.body.removeChild(divMensaje);
  }, 3000);
}
