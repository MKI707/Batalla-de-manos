<?php
$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_datos = "ranking";

$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$nombre = $_GET["nombre"];
$consulta = $conexion->prepare("SELECT puntaje FROM puntajes WHERE nombre = ?");
$consulta->bind_param("s", $nombre);
$consulta->execute();
$consulta->bind_result($puntaje);

if ($consulta->fetch()) {
    echo json_encode(["puntaje" => $puntaje]);
} else {
    echo json_encode(["puntaje" => 0]);
}

$consulta->close();
$conexion->close();
?>
