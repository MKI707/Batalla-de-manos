<?php
$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_datos = "ranking"; // Asegurate que este es el nombre correcto de tu base de datos

$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);

if ($conexion->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión"]);
    exit();
}

$sql = "SELECT nombre, puntaje FROM puntajes ORDER BY puntaje DESC LIMIT 100";
$resultado = $conexion->query($sql);

$ranking = [];

if ($resultado) {
    while ($fila = $resultado->fetch_assoc()) {
        $ranking[] = $fila;
    }
    echo json_encode($ranking);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Error al obtener datos"]);
}

$conexion->close();
?>
