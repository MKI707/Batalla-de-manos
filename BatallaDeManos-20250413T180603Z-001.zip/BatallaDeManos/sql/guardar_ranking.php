<?php
$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_datos = "ranking";

$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$nombre = $_POST["nombre"];
$puntaje = $_POST["puntaje"];

// Verificamos si el jugador ya existe
$consulta = $conexion->prepare("SELECT puntaje FROM puntajes WHERE nombre = ?");
$consulta->bind_param("s", $nombre);
$consulta->execute();
$consulta->store_result();

if ($consulta->num_rows > 0) {
    $consulta->bind_result($puntaje_anterior);
    $consulta->fetch();

    if ($puntaje > $puntaje_anterior) {
        $actualizar = $conexion->prepare("UPDATE puntajes SET puntaje = ? WHERE nombre = ?");
        $actualizar->bind_param("is", $puntaje, $nombre);
        $actualizar->execute();
        $actualizar->close();
    }
} else {
    $insertar = $conexion->prepare("INSERT INTO puntajes (nombre, puntaje) VALUES (?, ?)");
    $insertar->bind_param("si", $nombre, $puntaje);
    $insertar->execute();
    $insertar->close();
}

$consulta->close();
$conexion->close();
?>

